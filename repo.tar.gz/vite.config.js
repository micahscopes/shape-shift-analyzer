import { defineConfig } from 'vite'

export default defineConfig({
  base: '/shape-shift-analyzer/',
})